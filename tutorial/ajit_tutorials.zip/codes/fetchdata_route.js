var express = require('express');
var router = express.Router();
var tile1,tile2,tile3,tile4,tile5,tile6,tile7,tile8,tile9,bal1,bal2,bal3,bal4;
	tile1=0;
	tile2=0;
	tile3=0;
	tile4=0;
	tile5=0;
	tile6=0;
	tile7=0;
	tile8=0;
	bal1=bal2=bal3=bal4=tile9=0;
	
	var credit_amt =[];
	var debit_amt =[];
	var bank = [];
	var bankwise_credit = [];
		var bankd = [];
	var bankwise_debit = [];
	var global_user = 0;
	var g_month = 0;
	var g_year = 0;
	
/* GET home page. */
router.get('/', function(req, res, next) {
	
	global_user = req.app.locals.top;
	g_month = parseInt(req.app.locals.month);
	g_year = parseInt(req.app.locals.year);
	
  console.log('in the route user ='+global_user);
	//lets require/import the mongodb native drivers.
var mongodb = require('mongodb');

//We need to work with "MongoClient" interface in order to connect to a mongodb server.
var MongoClient = mongodb.MongoClient;

// Connection URL. This is where your mongodb server is running.
var url = 'mongodb://127.0.0.1:27017/r_db';

// Use connect method to connect to the Server
MongoClient.connect(url, function (err, db) {
  if (err) {
    console.log('Unable to connect to the mongoDB server. Error:', err);
  } else {
    //HURRAY!! We are connected. :)
    console.log('Connection established to', url);

    // Get the documents collection
    var collection = db.collection('users');

    // Insert some users
    collection.find({name: global_user,month:g_month,year:g_year}).toArray(function (err, result) {
      if (err) {
        console.log(err);
      } else if (result.length) {
		   tile1 = result[0].number_transactions_credit;
										   tile2 = result[0].totalamount_transactions_credit;
										   tile3 = result[0].averageamount_transactions_credit;
										   tile4 = result[0].number_transactions_debit;
										   tile5 = result[0].totalamount_transactions_debit;
										   tile6 = result[0].averageamount_transactions_debit;
										   tile7 = result[0].no_of_accounts;
										   tile8 = result[0].total_bank_balance;
										   
										   
										   ///////////////////////////////////last5////////////////////////////////////
										   
										   
										   collection.find({name: global_user,month:g_month-1,year:g_year}).toArray(function (err7, result7) {
												  if (err7) {
													console.log(err7);
												  } else if (result7.length) {
													  console.log('lasststtt month balance'+result7[0].total_bank_balance);
													    bal1 = result7[0].total_bank_balance;
													  
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
											collection.find({name: global_user,month:g_month-2,year:g_year}).toArray(function (err8, result8) {
												  if (err8) {
													console.log(err8);
												  } else if (result8.length) {
													  console.log('lasststtt month balance'+result8[0].total_bank_balance);
													    bal2 = result8[0].total_bank_balance;
													  
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
													collection.find({name: global_user,month:g_month-3,year:g_year}).toArray(function (err9, result9) {
												  if (err9) {
													console.log(err9);
												  } else if (result9.length) {
													  console.log('lasststtt month balance'+result9[0].total_bank_balance);
													    bal3 = result9[0].total_bank_balance;
													  
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
												collection.find({name: global_user,month:g_month-4,year:g_year}).toArray(function (err10, result10) {
												  if (err10) {
													console.log(err10);
												  } else if (result10.length) {
													  console.log('lasststtt month balance'+result10[0].total_bank_balance);
													    bal4 = result10[0].total_bank_balance;
													  
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});





										   ///////////////////////////////////////////////////////////////////////										   
										   
													var collection2 = db.collection(global_user);

												// Insert some users
												collection2.find({type:'credit'}).toArray(function (err2, result2) {
												  if (err2) {
													console.log(err2);
												  } else if (result2.length) {
													  var i =0;
													  while(result2[i]){
														  credit_amt[i] = result2[i].amount;
														  i++;
													  }
													  
															
																//res.render('index3',{credit_array:credit_amt});
														//console.log(tile1);							  
												 //   obj1 = JSON.parse(result[0]);
													//console.log(obj1.totalamount_transactions_credit);
													
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
												
													var collection3 = db.collection(global_user);

												// Insert some users
												collection3.find({type:'debit'}).toArray(function (err3, result3) {
												  if (err3) {
													console.log(err3);
												  } else if (result3.length) {
													  var i =0;
													  while(result3[i]){
														  debit_amt[i] = result3[i].amount;
														  i++;
													  }
													  
															
													
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
												
												var collection4 = db.collection(global_user+'_summary');

												// Insert some users
												
												collection4.aggregate([{"$match":{"bank_name":{"$exists":true}}},{$group : {_id : "$bank_name", total_credit : {$sum :"$total_credit_amount"}}}]).toArray(function (err4, result4) {
												  if (err4) {
													console.log(err4);
												  } else if (result4.length) {
													  var i =0;
													  while(result4[i]){
														  bank[i] =result4[i]._id;
														  console.log('each bankkkkk' + bank[i]);
														  bankwise_credit[i] =  +result4[i].total_credit;
														  i++;
													  }
													  
														
													
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
												collection4.aggregate([{"$match":{"bank_name":{"$exists":true}}},{$group : {_id : "$bank_name", total_debit : {$sum :"$total_debit_amount"}}}]).toArray(function (err5, result5) {
												  if (err5) {
													console.log(err5);
												  } else if (result5.length) {
													  var i =0;
													  while(result5[i]){
														  bankd[i] =result5[i]._id;
														  console.log('each bankkkkkdd' + bank[i]);
														  bankwise_debit[i] =  result5[i].total_debit;
														  i++;
													  }
													  
														
													
												  } else {
													console.log('No document(s) found with defined "find" criteria!');
												  }
												 
												});
												
												//collection4.aggregate([{"$match":{"city":{"exists":true}}},{$group:{_id:"$city",count:{$sum:1}}}]).
												collection4.aggregate([{"$match":{"city":{"$exists":true}}},{$group:{_id:"$city",count:{$sum:1}}}]).toArray(function (err6, result6) {
												  if (err6) {
													console.log(err6);
												  } else if (result6.length) {
													  tile9 = result6.length;
													  console.log("lennnnghhttt of cityyyy"+result6.length);
													  
													  
														
													
												  } else {
													console.log('location No document(s) found with defined "find" criteria!');
												  }
												 
												});
												
												console.log(tile1);
												console.log(tile2);
												console.log('creditttt' + credit_amt);
												console.log('debitttt' + debit_amt);
												console.log('banksss' + JSON.stringify(bank));
												console.log('bankwiseeee' + bankwise_credit);
										   
		   res.render('index3', {username_h:global_user, bankd_h:bankd, bankwise_debit_h: JSON.stringify(bankwise_debit),bank_h:bank, bankwise_credit_h:JSON.stringify(bankwise_credit), debit_array:JSON.stringify(debit_amt), credit_array:JSON.stringify(credit_amt), tile11: tile1,tile21: tile2,tile31: tile3,tile41: tile4,tile51: tile5,tile61: tile6,tile71: tile7,tile81: tile8, tile91:tile9, bal1_h:bal1, bal2_h:bal2, bal3_h:bal3, bal4_h:bal4, curr_month:g_month });

							db.close();			  
			//console.log(tile1);							  
     //   obj1 = JSON.parse(result[0]);
		//console.log(obj1.totalamount_transactions_credit);
		
      } else {
        console.log('No document(s) found with defined "find" criteria!');
      }
     
    });
	
	
	 
	
	
	/////////////end////
  }
});
	
	
	
  });

module.exports = router;
