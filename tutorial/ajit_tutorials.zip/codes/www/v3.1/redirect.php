<?php

$username = $_GET["username"];
$twitter_handle = $_GET["twitter_handle"];

if($username == 'reshul'){
	$ch = curl_init("http://localhost:3000/fetchdata");
	curl_exec($ch);
}
if($username == 'jay'){
	$ch2 = curl_init("localhost:3000/fetchdatajay");
	curl_exec($ch2);
}

?>