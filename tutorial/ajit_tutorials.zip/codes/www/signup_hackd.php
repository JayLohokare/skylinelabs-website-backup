<?php

	$json = file_get_contents('php://input');
	$json_array = json_decode($json,true); 
	// connect to mongodb
   //$m = new MongoClient();
	$m= new MongoClient("mongodb://127.0.0.1:27017");
   echo "Connection to database successfully";
   // select a database
   $db = $m->r_db;
	
	$name = $json_array["name"];
	$twitter_handle = $json_array["twitter_handle"];
	
	$collection = $db->user_names;
	
	
	$document = array( 
      "name" => $name, 
      "twitter_handle" => $twitter_handle
   );
	
   $collection->insert($document);
   echo "Document inserted successfully\n name-".$name."\ntwitter-".$twitter_handle;
 ?>