<?php
   // connect to mongodb
   //$m = new MongoClient();
	$m= new MongoClient("mongodb://localhost:27017");
   echo "Connection to database successfully";
   // select a database
   $db = $m->db1;
	$coll_name = $_GET["coll_name"];
	$collection = $db->$coll_name;
	$r = 'credit';
 // pull a cursor query
 $Query = array('type' => $r,'bank_name'=>'sbi',);
$cursor = $collection->find($Query);
 
 foreach($cursor as $document) {
 var_dump($document);
}

?>