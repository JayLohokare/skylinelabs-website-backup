<?php
   // connect to mongodb
   //$m = new MongoClient();
	$m= new MongoClient("mongodb://localhost:27017");
   echo "Connection to database successfully";
   // select a database
   $db = $m->r_db;
	
	$name = $_GET["name"];
	$month1 = $_GET["month"];
	$year1 = $_GET["year"];
	$twitter_handle = $_GET["twitter_handle"];
	
	$month = (int)$month1;
	$year = (int)$year1;
	
		$collection = $db->users;
						$cardQuery = array('name'=>$name,'twitter_handle'=>$twitter_handle,'year'=>$year,'month'=>$month);
						$cursor = $collection->find($cardQuery);
						
						$v1 = $cursor->fields(array("no_of_accounts" => true));
						foreach($v1 as $doc){
						var_dump($doc);	
						}
								




?>