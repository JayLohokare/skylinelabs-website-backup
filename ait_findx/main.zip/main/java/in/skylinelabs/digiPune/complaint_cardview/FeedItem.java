package in.skylinelabs.digiPune.complaint_cardview;

import android.graphics.Bitmap;

/**
 * Created by Reshul Dani on 07-10-2015.
 */
public class FeedItem {
    public String title;
    public String description;
    public String imgurl;
    public String id;
    public String latitude;
    public String longitude;



}
